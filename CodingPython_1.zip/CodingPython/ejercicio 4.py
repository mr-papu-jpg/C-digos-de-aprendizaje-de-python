n1=int(input("Igrese numero: "))
n2=int(input("Igrese numero: "))
n3=int(input("Igrese numero: "))

if n1>n2:
    if n1>n3:
        print("el numero mayor es ", n1)
elif n2>n1:
    if n2>n3:
        print("el numero mayor es ", n2)
    else:
        print("EL numero mayor es ", n3)        