import matplotlib.pyplot as plt

etapas = ['NumPy', 'Pandas', 'Matplotlib']
avance = [100, 100, 10]

plt.plot(etapas, avance, marker='o', color='purple')
plt.title('Camino del conocimiento')
plt.xlabel('Bloques')
plt.ylabel('Avance (%)')
plt.grid(True)
plt.show()