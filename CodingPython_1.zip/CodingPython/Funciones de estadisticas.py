import numpy as np

#Crear un array de datos simulados
datos = np.random.randint(10, 100, size=20)

#Calcular mediana
mediana = np.median(datos)

#Calcular percentil 25 y 75
p25 = np.percentile(datos, 25)
p75 = np.percentile(datos, 75)

#Calcular histograma
hist, bordes = np.histogram(datos, bins=5)

#Crear dos arrays correlacionados
x = np.random.rand(10)
y = x + np.random.normal(0, 0.1, size=10)  # y ≈ x con ruido

#Calcular correlación y covarianza
correlacion = np.corrcoef(x, y)
covarianza = np.cov(x, y)

print("Datos:", datos)
print("Mediana:", mediana)
print("Percentil 25:", p25)
print("Percentil 75:", p75)
print("Histograma:", hist)
print("Bordes:", bordes)
print("Correlación:\n", correlacion)
print("Covarianza:\n", covarianza)