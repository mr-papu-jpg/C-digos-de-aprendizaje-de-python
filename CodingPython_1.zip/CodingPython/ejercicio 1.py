n1=int(input("ingreae primer numero: "))
n2=int(input("ingrese segundo numero: "))

if n1>n2:
    dif=n1-n2
    print("la diferencia es de: ", dif)
else:
    prodc=n2%n1
    print("producto: ", prodc)    