import numpy

a = numpy.arange(10).reshape((5 ,2))
print("Cambia el Array de una dimension a una cantidad deseable: ", a)