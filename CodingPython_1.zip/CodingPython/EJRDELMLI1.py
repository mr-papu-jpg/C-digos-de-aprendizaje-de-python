empledos=[]
sueldos=[]
n=int(input("Ingrese la cantidad de empleados: "))
for x in range(n):
    emp=input("NOMBRE: \n>>")
    sul=float(input("SUELDO: \n>>"))
    empledos.append(emp)
    sueldos.append(sul)

for x in range(n):
    print(">>",empledos[x])
    print(">>",sueldos[x])
    print("~~~~")
cont=0
for x in range(n):
    if sueldos[x-cont]>10000:
        empledos.pop(x)
        sueldos.pop(x)
        n=n-1
        cont=cont+1
print(">>\n\n")
for x in range(n):
    print(">>",empledos[x])
    print(">>",sueldos[x])
    print("~~~~")