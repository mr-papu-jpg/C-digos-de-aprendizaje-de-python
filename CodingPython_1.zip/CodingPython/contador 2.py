list=[]
for x in range(0, 8):
    c=int(input("ingrese numero:>> "))
    list.append(c)
cont=0    
for x in range(0, 8):
    if list[x]==100:
            cont=cont+1
if cont>=1:
    print(f"La lista contiene {cont} de cantidades de neros '100'")