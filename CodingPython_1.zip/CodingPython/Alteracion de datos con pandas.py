import pandas as pd

data = {
    'Bloque': ['NumPy - Creación', 'NumPy - Manipulación', 'Pandas - Creación', 'Pandas - Inspección'],
    'Estado': ['Completado', 'Completado', 'Completado', 'En progreso']
}

df = pd.DataFrame(data)

print(df)
print()

df['Nivel']=[1, 2, 3, 4] #agrega una nueva columna

df['Avance'] = df['Nivel'] * 25  # Cálculo vectorizado

df.rename(columns={'Bloque':'Etapa'}, inplace=True)

df['Estado'] = df['Estado'].apply(lambda x: x.upper())

print(df)