import numpy.random

a = numpy.arange(5)
print(numpy.random.shuffle(a))

b = numpy.arange(9).reshape((3 , 3))
print(numpy.random.permutation(b))