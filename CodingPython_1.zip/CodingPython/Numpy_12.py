import numpy

a = numpy.arange(0 , 1 , 0.2)
print(a.tolist())

print(a.tofile( 'datos.dat', ';' , " %4.2f"))

print(a.tofile('binario.dat'))