x=int(input("ingrese coordenada x: "))
y=int(input("ingrese coordenada y: "))

if x==0 or y==0:
    print("ingrese numeroe que no sean '0'")
else:
    if x>0 and y>0:
        print("SE ubica en el cuadrante A")
    else:
        if x<0 and y>0:
            print("SE ubica en el cuadrante B")
        else:
            if x>0 and y<0:
                print("SE ubica en el cuadrante C")
            else:
                if x<0 and y<0:
                    print("SE ubica en el cuadrante D")