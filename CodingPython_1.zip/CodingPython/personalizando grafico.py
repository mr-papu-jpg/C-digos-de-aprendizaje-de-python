import matplotlib.pyplot as plt

etapas = ['NumPy', 'Pandas', 'Matplotlib']
avance = [100, 100, 10]

plt.style.use('ggplot')
plt.plot(etapas, avance, linestyle='--', marker='^', color='green')
plt.title('Camino del conocimiento')
plt.xlabel('Bloques', fontsize=12)
plt.ylabel('Avance (%)' ,fontsize=12)
plt.grid(True)
plt.show()