import numpy as np

#Fijar semilla para reproducibilidad
np.random.seed(7)

#Crear array de enteros aleatorios entre 10 y 100
enteros = np.random.randint(10, 100, size=8)

#Crear matriz 2x3 de floats entre 0 y 1
uniformes = np.random.rand(2, 3)

#Crear vector de 5 valores con distribución normal
normales = np.random.randn(5)

#Seleccionar 4 elementos aleatorios de una lista con probabilidades
seleccion = np.random.choice(['Sol', 'Luna', 'Estrella'], size=4, p=[0.2, 0.5, 0.3])

#Mezclar un array
mezcla = np.array([1, 2, 3, 4, 5])
np.random.shuffle(mezcla)

print("Enteros aleatorios:", enteros)
print("Uniformes:", uniformes)
print("Normales:", normales)
print("Selección:", seleccion)
print("Mezcla:", mezcla)