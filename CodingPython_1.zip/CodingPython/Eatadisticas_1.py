#estadisticas en numpy
import numpy

a = numpy.array([[5 , 6, 1] , [2 , 3, 8]])
print(a)

a2=numpy.amax(a)
print(a2)

a3=numpy.amax(a , axis =0)
print(a3)

a4=numpy.amax(a , axis =1)
print(a4)

a5=numpy.percentile(a , 25)
print(a5)

a6=numpy.percentile(a , 25 , axis =0)
print(a6)

a7=numpy.percentile(a , 25 , axis =1)
print(a7)

a8=numpy.ptp(a)
print(a8)

a9=numpy.ptp(a , axis =1)
print(a9)