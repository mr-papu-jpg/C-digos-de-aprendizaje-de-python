#ejemplo de uso de funciones para histogramas

import numpy

a = numpy.array([0 , 1 , 2 , 3 , 2, 4, 3, 3, 3, 5, 6, 9])

bins = numpy.arange(10)

print(numpy.histogram(a , bins ))

print(numpy.digitize(a , bins ))