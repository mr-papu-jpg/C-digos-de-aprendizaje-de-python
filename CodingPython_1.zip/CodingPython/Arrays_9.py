import numpy

a = numpy . arange (4)
ab = a > 1
print(ab)

b = numpy . ones (4 , dtype = numpy.bool)
print(b)

ab2=ab & b
print(ab2)

ab3=~ab
print(ab3)

ab4=ab | b
print(ab4)