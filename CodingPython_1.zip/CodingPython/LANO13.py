lista=[]
cant=int(input("ingrese cantidad\n>>"))
cant2=int(input("ingrese cantidad\n>>"))
cantsum=(cant*cant2)//2

for x in range(cantsum):
    n1=int(input(">> INGRESE NUMERO: "))
    n2=int(input(">> INGRESE NUMERO: "))
    lista.append([n1, n2])

print("\n _~~~~~~~~~_\n")
print(lista)
print("\n _~~~~~~~~~_\n")
ult=lista[cant-1][cant2-1]
print(ult)