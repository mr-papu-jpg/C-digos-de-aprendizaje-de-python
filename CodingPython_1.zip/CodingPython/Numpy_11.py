import numpy

a = numpy.arange (4)

print( a.dtype)

a = [1+1, 1+0, 4.5 , 3 , 2 , 2]
print(numpy.iscomplex(a))

print(numpy.iscomplexobj(a))

print(numpy.isreal(a))

print(numpy.isrealobj(a))

print(numpy.isscalar(a))

print(numpy.isscalar(1))