import numpy.polynomial.polynomial as npp

pol = npp.Polynomial([1 , 2 , 3])
print(pol)

pol2 = npp.Polynomial.fromroots([1 , -2])
print(pol2)