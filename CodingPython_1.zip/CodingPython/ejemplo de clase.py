class Persona:
    #Clase que representa una persona
    cedula="v-123456845"
    nombre="Leonardo"
    apellido="Caballero"
    sexo="M"