import zlib

s=b"hello wolrd"
len(s)
t=zlib.compress(s)
len(t)
zlib.decompress(t)