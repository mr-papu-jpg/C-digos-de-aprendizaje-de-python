import numpy

a = numpy.array([[1 , 2, 3] , [4 , 5, 6]])
b = numpy.zeros(2)
c = numpy.arange(8).reshape((2 ,4))
d=numpy.vstack(( a.T , b ))
print("Mostrando combinacion ordenada de a y b: \n",d)
e=numpy.hstack (( a , c ))
print("Mostrando combinacion ordenada de a y c: \n",e)

#uso de enteros negativos
a = numpy.arange ( -1 , 4)
print("Array con enteros negativos: ",a)