import matplotlib.pyplot as plt

fig, axs = plt.subplots(2, 2)  # 2 filas, 2 columnas

axs[0, 0].plot([1, 2, 3], [10, 20, 30])
axs[0, 0].set_title('Gráfico 1')

axs[0, 1].bar(['A', 'B', 'C'], [5, 7, 3])
axs[0, 1].set_title('Gráfico 2')

axs[1, 0].scatter([1, 2, 3], [30, 20, 10])
axs[1, 0].set_title('Gráfico 3')

axs[1, 1].pie([40, 60], labels=['Sí', 'No'], autopct='%1.1f%%')
axs[1, 1].set_title('Gráfico 4')

plt.tight_layout()



plt.grid(True)
plt.show()