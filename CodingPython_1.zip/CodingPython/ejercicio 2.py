not1=int(input("primera nota:"))
not2=int(input("segunda nota:"))
not3=int(input("tercera nota:"))

promd=(not1+not2+not3)/3

if promd>=7:
    print("PROMOCIONADO")
else:
    print("no paso")