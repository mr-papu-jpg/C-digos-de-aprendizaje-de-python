from random import*

def generarNumeroAlearorio(mínimo, maximo):
    return randint(mínimo, maximo)
    
numero_buscado=generarNumeroAlearorio(1,100)
encontrado=False
intentos=0

while not encontrado:
    numero_usuario=int(input("Introduce el numero buscado: "))
    if numero_usuario>numero_buscado:
        print("El numero que buscas es menor")
        intentos=intentos+1
    elif numero_usuario<numero_buscado:
        print("El numero que buscas es mayor")
        intentos=intentos+1
    else:
        encontrado=True
        print("Has encontrado el numero correcto, te llevo", intentos, "intentos")