#estadisticas en numpy
import numpy

b = numpy.array([[5 , numpy . nan , 1] , [2 , 3, numpy . nan ]])
print(numpy.amin(b))

print(numpy.amax(b))

print(numpy.nanmin(b))

print(numpy.nanmin(b , axis =0))

print(numpy.nanmin(b , axis =1))

print(numpy.nanmax(b , axis =1))

print(numpy.ptp(b))

print(numpy.ptp(b , axis =0))

print(numpy.ptp(b , axis =1))