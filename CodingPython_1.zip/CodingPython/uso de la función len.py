nombre='juan'
print(len(nombre))