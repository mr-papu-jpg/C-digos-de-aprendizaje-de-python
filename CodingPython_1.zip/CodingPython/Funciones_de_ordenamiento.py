import numpy as np

#Crear un array aleatorio de 10 elementos entre 1 y 50
a = np.random.randint(1, 50, size=10)

#Ordenarlo
ordenado = np.sort(a)

#Obtener los índices del orden
indices = np.argsort(a)

#Buscar dónde insertar el número 25
insertar = np.searchsorted(ordenado, 25)

#Obtener índice del máximo y mínimo
max_idx = np.argmax(a)
min_idx = np.argmin(a)

#Encontrar elementos mayores a 30
mayores = np.where(a > 30)

#Mostrar índices de elementos no cero
no_ceros = np.nonzero(a)

print("Original:", a)
print("Ordenado:", ordenado)
print("Índices de orden:", indices)
print("Insertar 25 en:", insertar)
print("Índice máximo:", max_idx)
print("Índice mínimo:", min_idx)
print("Mayores a 30:", mayores)
print("No ceros:", no_ceros)