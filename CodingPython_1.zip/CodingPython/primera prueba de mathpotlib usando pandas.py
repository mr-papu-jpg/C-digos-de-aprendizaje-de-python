import pandas as pd
import matplotlib.pyplot as plt

data = {
    'Etapa': ['NumPy - Creación', 'NumPy - Manipulación', 'Pandas - Creación', 'Pandas - Inspección', 'Pandas - Agrupamiento'],
    'Estado': ['Completado', 'Completado', 'Completado', 'En progreso', 'En progreso'],
    'Nivel': [1, 2, 3, 4, 5],
    'Avance': [25, 50, 75, 100, 125]
}

df = pd.DataFrame(data)

df['Avance'].hist(bins=5)
df.plot(x='Etapa', y='Avance', kind='line')
df['Estado'].value_counts().plot.pie(autopct='%1.1f%%')


plt.show()