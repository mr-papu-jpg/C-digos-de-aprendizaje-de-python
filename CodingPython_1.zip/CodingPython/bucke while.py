print("programa para ingresar notas de alumnos\n~~~~~~~\n")

i=1
contmay=0
contmen=0

while i<10:
    alumno=int(input(f"{i}>>ingrese nota: "))
    if alumno>=7:
        contmay=contmay+1
    else:
        contmen=contmen+1  
    i=i+1
    
print("La cantidad de alumnos que aprobaron es de: ", contmay) 
print("La cantidad de alumnos de menor nota es de: ", contmen) 