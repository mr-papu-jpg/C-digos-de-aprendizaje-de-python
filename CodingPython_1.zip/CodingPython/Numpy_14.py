import numpy

a = numpy.array([[1 , 2] , [3 , 4] , [5 , 6]])

print(numpy.compress([0 , 1] , a , axis =0))

print(numpy.compress ([ False , True , True ], a , axis =0))

print(numpy.compress([ False , True ] , a , axis =1))