#manejo de archivos
objetoArchivo=open("spoilerito.txt", "w")
objetoArchivo.write("Hello world")
objetoArchivo.close()
