n1=int(input("ingrese un numero: "))
n2=int(input("ingrese un numero: "))
n3=int(input("ingrese un numero: "))

if n1==n2 and n1==n3:
    res=(n1+n2)*n3
    print("Todos fueron iguales, su calculo es: ", res)
else: 
    print("\nNO se hizo calculo")    
    