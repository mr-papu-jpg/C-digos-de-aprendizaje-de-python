import numpy as np

ar = np.arange(1, 13, 1, dtype = int)
print('\n', ar)

ar1, ar2, ar3=np.split(ar, 3)
print("\n", ar1, ar2, ar3)

c = np.concatenate((ar1, ar2), 0)
print("\n", c)