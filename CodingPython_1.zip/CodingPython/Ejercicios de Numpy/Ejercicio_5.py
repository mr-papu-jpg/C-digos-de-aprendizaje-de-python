import numpy as np

ar = np.arange(1, 5, 1, dtype = int)
print('\n', ar)

ar1= np.reshape(ar, (2,2))
print('\n', ar1)

arr = np.arange(5, 9, 1, dtype = int)
print('\n', arr)

arr1= np.reshape(arr, (2,2))
print('\n', arr1)

af = np.dot(ar1,arr1)
print('\n', af)

el_af = np.power(af, 2)
print('\n', el_af)