import numpy as np

ar = np.random.randint(1, 100, (2, 3, 4))

print(ar)

print(ar.shape)

print(ar.ndim)

print(ar.size)

print(ar.dtype)

ar2=ar.flatten()
print(ar2)

ordenado=np.sort(ar2)

print(ordenado)