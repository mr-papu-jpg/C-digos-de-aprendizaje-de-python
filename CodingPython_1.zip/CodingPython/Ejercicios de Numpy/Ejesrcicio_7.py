import numpy as np

on = np.ones((2, 3, 4))
print("\n", on)

print("\n", on.shape)

print("\n", on.ndim)

print("\n", on.size)

print("\n", on.dtype)