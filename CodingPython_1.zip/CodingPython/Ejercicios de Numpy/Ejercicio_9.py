import numpy as np

# Paso 1: Crear array aleatorio de 10 elementos entre 1 y 100
array_original = np.random.randint(1, 100, size=10)
print("Array original:", array_original)

# Paso 2: Ordenar el array
array_ordenado = np.sort(array_original)
print("Array ordenado:", array_ordenado)

# Paso 3: Convertirlo en matriz 2x5
matriz = array_ordenado.reshape((2, 5))
print("Matriz 2x5:\n", matriz)

# Paso 4: Calcular la suma por filas (axis=1)
suma_filas = np.sum(matriz, axis=1)
print("Suma por filas:", suma_filas)