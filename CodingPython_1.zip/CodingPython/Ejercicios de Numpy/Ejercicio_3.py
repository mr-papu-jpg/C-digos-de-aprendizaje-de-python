import numpy

ar1 = numpy.arange(1, 10, 1)
print('\n', ar1)

ar2 = numpy.reshape(ar1, (3,3))
print('\n', ar2)

ar3 = numpy.transpose(ar2)
print('\n',ar3)

ar4 = ar3.flatten()
print('\n',ar4)