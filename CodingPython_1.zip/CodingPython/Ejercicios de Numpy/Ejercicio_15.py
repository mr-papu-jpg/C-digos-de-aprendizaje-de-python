import numpy as np

ar = np.random.randint(1, 100, (12))

print(np.random.shuffle(ar))

ar2=np.reshape(ar, (3, 4))
print(ar2)

print(np.sum(ar2, axis=1))

print(np.sum(ar2, axis=0))