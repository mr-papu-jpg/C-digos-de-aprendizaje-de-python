import numpy as np

ar = np.random.randint(1, 21, (20))

print(ar)

promedio = np.mean(ar)

print(promedio)

desviacion=np.std(ar)

print(desviacion)

mediana=np.median(ar)

print(mediana)

percentiles=np.percentile(ar, 25)

print(percentiles, " (25)")

percentiles=np.percentile(ar, 75)

print(percentiles, " (75)")

hist, bins=np.histogram(ar, bins=4)

print(hist)