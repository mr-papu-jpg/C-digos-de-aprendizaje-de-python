import numpy as np

ar = np.random.randint(1, 200, (2, 2))

determinante=np.linalg.det(ar)
print(determinante)

inversa=np.linalg.inv(ar)
print(inversa)

val_pro=np.linalg.eig(ar)
print(val_pro)

vect_pro=np.linalg.solve(ar)
print(vect_pro)