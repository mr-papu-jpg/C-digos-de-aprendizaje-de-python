producto=[]
precio=[]

for x in range(5):
    prod=input("Ingrese nombre del producto:>> ")
    prec=int(input("Ingrese precio:>> "))
    producto.append(prod)
    precio.append(prec)
cont=0
pos=[]
for x in range(5):
    if precio[0]<precio[x]:
        cont=cont+1
        pos.append(x)
        
print("Productos con mayor precio ingresado:\n~~~~~~~~~~~")
for x in range(len(pos)):
    print(">>",producto[pos[x]], "||")