print("promediando operario: ")

sueldo=float(input("ingrese el sueldo del empleado: \n"))
antig=int(input("ingrese antiguedad: \n"))
pojr=sueldo/100

if sueldo<500 and antig>=10:
    sueldo=(pojr*20)+sueldo
    print("SUEKDO TOTAL: ", sueldo)
else:
    if sueldo<500 and antig<10:
        sueldo=(pojr*5)+sueldo
        print("SUEKDO TOTAL: ", sueldo)
    else:
        if sueldo>=500:
            print("SUEKDO TOTAL: ", sueldo)    