#manejo de ecepciones
while True:
    try:
        variable1=int(input("Ingrese el primer valor: "))
        break
    except ValueError:
        print("El valor debe ser numerico")
while True:
    try:
        variable2=int(input("Ingrese el segundo valor: "))
        break
    except ValueError:
        print("El valor debe de ser numerico")

suma=variable1+variable2
print("la suma de var1=", variable1," y var2=", variable2, " es igual a ",suma)        