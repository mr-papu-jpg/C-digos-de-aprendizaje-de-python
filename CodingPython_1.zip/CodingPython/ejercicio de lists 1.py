list=[]
for x in range(0, 5):
    c=int(input("ingrese numero:>> "))
    list.append(c)
pos=[]    
print("Impresion de loa valores mayores a 7")
for x in range(0, 5):
    if list[x]>=7:
            print(">> ",list[x])