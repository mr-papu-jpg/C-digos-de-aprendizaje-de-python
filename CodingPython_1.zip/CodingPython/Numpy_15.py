import numpy

b = numpy.arange(10)
b = b.reshape((2 ,5))
print(b)

b2=numpy.argmax(b)
print(b2)

b3=numpy.argmax(b , axis =0)
print(b3)

b4=numpy.argmax(b , axis =1)
print(b4)

d = numpy.arange(4)
e=d/2
print(e)

e2=numpy.isnan(e)
print(e2)

e3=numpy.isinf(e)
print(e3)