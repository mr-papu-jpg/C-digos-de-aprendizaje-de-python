import pandas as pd

data = {
    'Bloque': ['NumPy - Creación', 'NumPy - Manipulación', 'Pandas - Creación'],
    'Estado': ['Completado', 'Completado', 'En progreso'],
    'Reflexión': ['El inicio del orden', 'Transformar con elegancia', 'Dar forma al alma de los datos']
}

df = pd.DataFrame(data)

#Inspección
print(df.head())
print(df.shape)
print(df.columns)
print(df.info())

print()

print(df['Bloque'])
print(df['Estado']=='Completado')
print()
print(df.loc[2])
print()
print(df.query("Bloque == 2 and Estado=='Completado'"))
