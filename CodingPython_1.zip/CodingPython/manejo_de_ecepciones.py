#manejo de exepciones
while True:
    try:
        valor1=int(input("Por favor ingrese el primer numero: "))
        break
    except ValueError:
        print("valor invalido, intente de nuevo")    