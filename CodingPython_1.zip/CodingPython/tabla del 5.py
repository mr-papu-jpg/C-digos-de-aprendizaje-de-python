print("tablas de multiplicar:")
print("~~~~~~~~~")
for i in range(1, 11):
    r=i*5
    print(i, "x 5 = ", r)
print("~~~~~~~~~")