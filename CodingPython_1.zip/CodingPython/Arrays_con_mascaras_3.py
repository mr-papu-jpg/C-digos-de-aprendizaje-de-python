import numpy.ma

y = numpy.ma.array([3 , -1, 2, 5] , mask =[0 , 0, 1 , 1])

print(numpy.ma.max(y))

print(numpy.ma.ptp(y))

print(numpy.ma.std(y))

print(numpy.ma.median( y))