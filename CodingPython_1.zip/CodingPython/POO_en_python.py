class Persona:
    #Clase que representa una persona
    nombre="Leonardo"
    apellido="Caballero"
    
    def nombre(self, name):
        #cargar nombre de la persona
        self.nombre=name
    def apellido(self, lname):
        #cargar apellido de la persona
        self.apellido=lname
    def mostrarNombre(self):
        #imprimir nombre de la persona
        print(self.nombre)   
    def mostrarApellido(self):
        #imprimir apellido de la persona
        print(self.apellido)      
        
pepe=Persona()
pepe.nombre("Jose")
pepe.mostrarNombre()           