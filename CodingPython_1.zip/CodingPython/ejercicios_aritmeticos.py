x=((1+2)-3)+4
y=(1-2)+(3+4)
z=1+(2-(3+4))

print(x)
print(y)
print(z)