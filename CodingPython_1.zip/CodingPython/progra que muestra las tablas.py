print("tablas de multiplicar:")
print("~~~~~~~~~")
n=int(input("ingrese tabla a multiplicar:"))
print("~~~~~~~~~")

for i in range(1, 13):
    r=i*n
    print(i, "x ",n," = ", r)
print("~~~~~~~~~")