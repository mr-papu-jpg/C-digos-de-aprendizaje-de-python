import numpy.ma

x = numpy.ma.array([1 , 2, 3, 4] , mask =[0 , 0 , 1, 0])

y = numpy.ma.array([3 , -1, 2, 5] , mask =[0 , 0, 1 , 1])

print(x + y)