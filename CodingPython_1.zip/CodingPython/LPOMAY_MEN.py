print(">>INGRESE NUMEROS: ")
print("_-_-_-_-_-_")

nums=[]
for x in range(5):
    num=int(input(">>NUMERO: "))
    nums.append(num)
    print("-------")
  
for k in range(4):
    for x in range(4-k):
        if nums[x]<nums[x+1]:
            aux1=nums[x]
            nums[x]=nums[x+1]
            nums[x+1]=aux1

for x in range(5):
    print(">>",nums[x])  
print("~~~")
    
for k in range(4):
    for x in range(4-k):
        if nums[x]>nums[x+1]:
            aux1=nums[x]
            nums[x]=nums[x+1]
            nums[x+1]=aux1
            

for x in range(5):
    print(">>",nums[x])
print("~~~")