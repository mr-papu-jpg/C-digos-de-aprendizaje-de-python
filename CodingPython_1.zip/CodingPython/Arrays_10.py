import numpy

a = numpy.arange(4)
b = numpy.array([0 , 1 , 2.2 , 3.1])
ab2=numpy.allclose(a , b , atol =0.25)
print(ab2)

ab3=numpy.allclose(a , b , atol =0.15)
print(ab3)

c = numpy.array ([[ False , False ], [ True , True ]])
print(c)

c2=numpy.all(c , axis =0)
print(c2)

c3=numpy.all(c , axis =1)
print(c3)

ab4=numpy.array_equal (a , b)
print(ab4)

a2=numpy.array_equal(a , a)
print(a2)

ab5=numpy.greater(a , b)
print(ab5)

ab6=numpy.greater_equal(a , b )
print(ab6)

ab7=numpy.less(a , b)
print(ab7)

ab8=numpy.not_equal (a , b)
print(ab8)