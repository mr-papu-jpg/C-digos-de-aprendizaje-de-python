def men_3vals(n1, n2, n3):
    if n1>n2 and n1>n3 and n2>n3:
            print(n3,"\n",n2,"\n",n1)
    if n1>n2 and n1>n3 and n3>n2:
            print(n2,"\n",n3,"\n",n1)
    if n2>n1 and n2>n3 and n1>n3:
            print(n3,"\n",n1,"\n",n2)
    if n2>n1 and n2>n3 and n3>n1:
            print(n1,"\n",n3,"\n",n2)
    if n3>n1 and n3>n2 and n2>n1:
            print(n1,"\n",n2,"\n",n3)
    if n3>n1 and n3>n2 and n1>n2:
            print(n2,"\n",n1,"\n",n3)
          
        
#programa principal
n1=int(input("INGRESE NUMERO: "))
n2=int(input("INGRESE NUMERO: "))
n3=int(input("INGRESE NUMERO: "))
men_3vals(n1, n2, n3)
print("\n~~~~~\n")