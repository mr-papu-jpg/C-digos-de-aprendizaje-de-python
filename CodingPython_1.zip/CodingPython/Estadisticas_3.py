import numpy

a = numpy.arange(4).reshape ((2 , 2))
print(a)

print(numpy.average(a , axis =1 , weights =(0 , 1)))

print(numpy.mean(a , axis =0))

print(numpy.mean(a , axis =1))

print(numpy.median(a))

print(numpy.median(a , axis =1))

print(numpy.std(a))

print(numpy.var(a))

print(numpy.std(a ) * numpy.std(a))