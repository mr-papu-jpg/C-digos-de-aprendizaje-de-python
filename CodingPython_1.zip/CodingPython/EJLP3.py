nom=[]
n=[]

for x in range(4):
    nog=input(">>INGRESE NOMBRE: ")
    nof=int(input(">>INGRESE NOTA: "))
    nom.append(nog)
    n.append(nof)
    print(">>~~~~<<")
    
for x in range(4):
    print(">>",nom[x])
    if n[x]>7:
        print(">>nota: MUY BUENO")
    if n[x]<5:
        print(">>nota: BUENO") 
    if n[x]<=4 and n[x]!=5:
        print(">>nota: INSUFICIENTE")