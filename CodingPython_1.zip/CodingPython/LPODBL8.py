print("CARGAR LISTA DE 5 PAISES")
paises=[]
habitantes=[]
for x in range(5):
    p=input(">>Escribe el pais: ")
    paises.append(p)
    h=int(input(">>Escribe la cantidad de habitantes: "))
    habitantes.append(h)
    print("\n~~~~~~\n")

for x in range(4):
    for k in range(4-x):
        if paises[k]>paises[k+1]:
            aux1=paises[k]
            paises[k]=paises[k+1]
            paises[k+1]=aux1
            aux2=habitantes[k]
            habitantes[k]=habitantes[k+1]
            habitantes[k+1]=aux2

for x in range(5):
    print(paises[x])
    print(habitantes[x])
    print("~~___~~")

print("<<~~~~~~~>>")    
for x in range(4):
    for k in range(4-x):
        if habitantes[k]>habitantes[k+1]:
            aux1=paises[k]
            paises[k]=paises[k+1]
            paises[k+1]=aux1
            aux2=habitantes[k]
            habitantes[k]=habitantes[k+1]
            habitantes[k+1]=aux2

for x in range(5):
    print(paises[x])
    print(habitantes[x])
    print("~~___~~")