#Para eliminar elementos de una lista 
#también es empleada la función "del" pasando como parámetro la referencia de la componente a eliminar:

lista=[10, 20, 30, 40, 50]

print(lista)

del(lista[0])
del(lista[1])
del(lista[2])

print(lista) # 20 40