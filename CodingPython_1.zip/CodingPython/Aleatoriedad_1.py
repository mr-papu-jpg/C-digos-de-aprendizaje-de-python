import numpy.random

print(numpy.random.rand(2 , 3))

print(numpy.random.randn(4))

print(numpy.random.randint(0 , 11 , size =(2 , 3)))

a = numpy.arange(5)
print(numpy.random.choice(a , size =4))

print(numpy.random.choice(a , size =4 , replace = False))