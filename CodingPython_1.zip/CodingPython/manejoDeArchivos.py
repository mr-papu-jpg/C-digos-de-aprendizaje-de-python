import fibo

fibo.fib(1000)
fibo.fib2(100)
fibo.__name__