lista=[10, 20, 30]
print(len(lista))    # imprime un 3
lista.append(100)
print(len(lista))    # imprime un 4
print(lista[0])      # imprime un 10
print(lista[3])