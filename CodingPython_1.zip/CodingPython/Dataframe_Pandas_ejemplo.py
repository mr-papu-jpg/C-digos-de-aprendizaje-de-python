import pandas as pd

data = {
    'Bloque': ['NumPy - Creación', 'NumPy - Manipulación', 'Pandas - Creación'],
    'Estado': ['Completado', 'Completado', 'En progreso'],
    'Reflexión': ['El inicio del orden', 'Transformar con elegancia', 'Dar forma al alma de los datos']
}

df = pd.DataFrame(data)
print(df)