clave=input("Ingrese clave :>> ")
cont=len(clave)

if cont>20:
    print("<<ERROR>>//Ingrese una clave entre 20 o 10 caracteres o numeros.") 