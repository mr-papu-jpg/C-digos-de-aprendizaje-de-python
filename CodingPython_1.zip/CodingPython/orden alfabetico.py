nombres=[]
for x in range(0, 2):
    n=input("Nombre: ")
    nombres.append(n)

if nombres[0]>nombres[1]:
    print(nombres[0], "\n", nombres[1])
else:
    print(nombres[1], "\n", nombres[0])