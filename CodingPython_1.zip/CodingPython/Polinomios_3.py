import numpy
import numpy.polynomial.polynomial as npp

x = numpy.arange( -2 , 2, 0.2)
y = numpy.power(x , 2)

noise = numpy.random.randn( x. size )

res = npp.polyfit(x , y + noise , 2, full = True , \
w =1/ numpy.power ( noise , 2))

print(res)