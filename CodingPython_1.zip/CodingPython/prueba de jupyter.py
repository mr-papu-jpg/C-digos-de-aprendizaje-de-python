# 📊 Prueba de visualización con matplotlib
import matplotlib.pyplot as plt
import numpy as np

# Datos simulados
x = np.linspace(0, 10, 100)
y = np.sin(x)

# Gráfico
plt.figure(figsize=(8, 4))
plt.plot(x, y, label='Seno de x', color='purple')
plt.title('Gráfico de prueba en Jupyter')
plt.xlabel('x')
plt.ylabel('sin(x)')
plt.legend()
plt.grid(True)
plt.show()