n1=int(input("ingrese un numero: "))
n2=int(input("ingrese un numero: "))
n3=int(input("ingrese un numero: "))

if n1<10 and n2<10 and n3<10:
    print("todos loa numeros son menores a 10")
else:
    print("Algunos de los numero o todos son mayores a 10")