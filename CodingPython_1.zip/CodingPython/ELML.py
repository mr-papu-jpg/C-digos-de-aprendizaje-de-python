enteros=[]
n=int(input("Ingrese cantidad de numeros: "))
for x in range(n):
    ent=int(input("ENTERO: \n>>"))
    enteros.append(ent)
print("\n\n")
for x in range(n):
    print(">>",enteros[x])
    print("~~~~")
print("\n\n")
cont=0
for x in range(n):
    if enteros[x-cont]>=10:
        enteros.pop(x)
        n=n-1
        cont=cont+1
print("\n\n")
for x in range(n):
    print(">>",enteros[x])
    print("~~~~")