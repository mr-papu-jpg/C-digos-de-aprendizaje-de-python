def al_cuadrado():
    qu=float(input("CALCULE EL CUADRADO: "))
    quar=qu*qu
    print(f"EL CUADRADO ES: {quar}")
    
al_cuadrado()    