import numpy

arr = numpy.arange(12).reshape((3 , 4))

print(arr)

condition = numpy.mod( arr , 3)==0

arr_2=numpy.extract( condition , arr )

print(arr_2)