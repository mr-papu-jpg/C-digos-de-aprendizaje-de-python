import numpy

a = numpy.arange(6).reshape((3 , 2))
print("Orden sin alterar: ",a)

print("Orden alterado a C: ",a.flatten(order ="C"))

print("Orden alterado a F: ",a.flatten(order ="F"))

print("\nEstos metodos permiten cambiar la dimencion de un Array de multiples dimensiones a una sola dimension...")