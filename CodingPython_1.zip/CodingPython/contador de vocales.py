chara=input("Ingrese una oracion:>> ")
chara_low=chara.lower()
cont_voc=0
print("~~~~~~~~~~")
for x in range(0, len(chara)):
    if chara_low[x]=='a' or chara_low[x]=='e' or chara_low[x]=='i' or chara_low[x]=='o' or chara_low[x]=='u':
        cont_voc=cont_voc+1
print(f"La palabra {chara} posee {cont_voc} vocales.")        