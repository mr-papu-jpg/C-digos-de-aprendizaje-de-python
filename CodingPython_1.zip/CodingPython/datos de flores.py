from sklearn.datasets import load_iris

iris = load_iris()
print("Características:", iris.feature_names)
print("Clases:", iris.target_names)