def cont_vocl(plb):
    h=plb.lower()
    cont_v=0
    for x in range(len(h)):
        if h[x]=="a" or h[x]=="e" or h[x]=="i" or h[x]=="o" or h[x]=="u":
            cont_v=cont_v+1
    print("La cantidad de vocales es: ", cont_v)
    
print("Contador de vocales")
palabra=input("INGRESE palabra: \n>>")
cont_vocl(palabra)
print("\n~~~~~~~~~~\n")
palabra=input("INGRESE palabra: \n>>")
cont_vocl(palabra)
print("\n~~~~~~~~~~\n")
palabra=input("INGRESE palabra: \n>>")
cont_vocl(palabra)