import numpy

a = numpy.ones(10)
print("Mostrando cantidad de arrays: ",a.shape)

a.shape=[2 ,5]
print("Mostrando un array de dos dimensiones: ",a)

b=a.reshape((2 ,5))
print("Mostrando prueba de una funcion: ",a. shape)