def men_3vals():
        n1=int(input("INGRESE NUMERO: "))
        n2=int(input("INGRESE NUMERO: "))
        n3=int(input("INGRESE NUMERO: "))
        may=0
        if n1>n2 and n1>n3:
            may=n1
        if n2>n1 and n2>n3:
            may=n2
        if n3>n1 and n3>n2:
            may=n3
        print("el mayor es", may)    
        
#programa principal
men_3vals()
print("\n~~~~~\n")
men_3vals()
print("\n~~~~~\n")
men_3vals()