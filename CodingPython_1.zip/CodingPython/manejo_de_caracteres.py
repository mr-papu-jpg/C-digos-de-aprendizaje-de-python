palabra="python"

print(palabra[2:5])
print(palabra[-1])