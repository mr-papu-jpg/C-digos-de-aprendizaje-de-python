import numpy

a = numpy . arange (4)
print("Array generado de forma comun",a)

a2=a > 2
print("Comparacion aritmetica de cada entero del Array > 2: \n", a2)

a3=a >= 2
print("Comparacion aritmetica de cada entero del Array >= 2: \n", a3)

a4=a < 9
print("Comparacion aritmetica de cada entero del Array < 9: \n", a4)

b = numpy . array ([0 , 1 , 3 , 3])

b2=a == b
print("Comparacion aritmetica de cada entero del Array a == Array b: \n",b2)

b3=a != b
print("Comparacion aritmetica de cada entero del Array a != Array b: \n",b3)