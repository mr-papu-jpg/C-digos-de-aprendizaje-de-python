class Perro:
    def __init__(self, nombre):
        #metodo constructor
        self.nombre=nombre
        self.trucos=[]
    def agregar_truco(self,truco):
        self.trucos.append(truco)
        
#Creacion de objetos
d=Perro("Fido")
e=Perro("Buddy")
d.agregar_truco("girar")
e.agregar_truco("hacerse el muerto")
print(d.trucos)
print(e.trucos)