with open("spoilerito.txt") as objetoArchivo:
    objetoArchivo.read(10)
    posCursor=objetoArchivo.tell()
    print(posCursor)
    objetoArchivo.seek(11)
    posCursor2=objetoArchivo.tell()
    print(posCursor2)