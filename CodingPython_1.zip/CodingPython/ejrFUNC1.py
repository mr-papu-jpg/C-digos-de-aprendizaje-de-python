def cuadrado():
    quz=int(input("INGRESE NUMERO A SACAR CUADRADO: "))
    quar=quz*quz
    print(f"El cuadrado es: {quar}.")

def producto():
        n1=int(input("INGRESE NUMERO: "))
        n2=int(input("INGRESE NUMERO: "))
        prod=n1*n2
        print(f"El produc!o de {n1} y {n2} es: {prod}")
        
#programa principal
cuadrado()
print("\n~~~~~\n")
producto()        