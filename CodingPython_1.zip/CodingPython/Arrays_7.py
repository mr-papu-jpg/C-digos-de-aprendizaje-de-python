import numpy

op1 = numpy.zeros([2 ,3]) + 3
op2 = numpy.array([[0 ,1 ,2] ,[3 ,4 ,5]])

print("Operacion aritmetica comun: \n",op1)
print("Ejemplo ya antes visto: \n",op2)

op3=op1 * op2

print("Producto de dos Arrays: \n", op3)