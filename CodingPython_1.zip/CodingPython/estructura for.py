for x in range(20,51): #parqmetro 1 es el comienzo del contador
    print(x)            #parametro dos, es el fin del contador