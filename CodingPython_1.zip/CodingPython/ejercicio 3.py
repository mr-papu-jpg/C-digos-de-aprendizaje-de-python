n=int(input("infrese numero: "))

if n>=10:
    print("el numero tiene 2 digitos...")
else:
    print("el numero solo tiene un digito...")   