for x in range(1,100,2): # el tercerr parámetro indica cuánto incrementa cada vuelta
    print(x)