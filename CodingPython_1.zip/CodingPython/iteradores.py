#Iteradores
s="abc"
it=iter(s)
print(it)
next(it)
print(it)
next(it)
print(it)