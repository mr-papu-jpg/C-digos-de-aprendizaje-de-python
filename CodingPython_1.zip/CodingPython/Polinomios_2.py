import numpy.polynomial.polynomial as npp

c1 = [0 , 2, 3]
c2 = [0 , 1]

print(npp.polyadd(c1 , c2 ))

print(npp.polysub(c1 , c2 ))

print(npp.polymul(c1 , c2 ))

print(npp.polydiv(c1 , c2 ))