import pandas as pd

data = {
    'Etapa': ['NumPy - Creación', 'NumPy - Manipulación', 'Pandas - Creación', None],
    'Estado': ['Completado', 'Completado', 'En progreso', 'En progreso'],
    'Nivel': ['1', '2', None, '4']
}

df = pd.DataFrame(data)

print(df.isnull())

print(df.isnull().sum())

df['Nivel'].dropna()	#eliminacion de nulos

df['Nivel'].fillna(0)	#rellena nulos con 0

df['Nivel'].fillna(method='ffill')

print()

print(df)