import numpy
tupla = (3 , 5, 7.7)
a2 = numpy . array ( tupla )
print("Creacion de un array desde una tupla: \n",a2)
a4 = numpy . array ([ ' linea1 ', ' linea2 ' , 33])
print("Creacion de un array de caractes y de numeros enteros: \n", a4)
a5 = numpy.array ([[1 , 2, 3, 4] ,[5 , 6, 7, 8] , [9 , 10 , 11 , 12]])
a5.shape
print("Creacion de un Array con;mas de una dimension: \n", a5)

a6=numpy.arange(5 , 6, 0.1)
print("Prueba de una funcion que crea;un array recoriendolo de manera decimal (aunque puede ser entera): \n", a6)

a7=numpy.linspace(5 , 6 , 5)
print("Prueba de Funcion de array: \n",a7)

a8=numpy.linspace (5 , 6 , 5 , False , True )
print("Otra prueba de funcion de array: \n",a8)

a9=numpy.ones(4 , dtype = numpy . complex128 )
print("Otra prueba de funcion de array: \n",a9)

b1=numpy.zeros((2 ,3 ,4))
print("Otra prueba de funcion de array: \n",b1)

b2=numpy.arange(10)

print("Otra prueba de funcion de array: \n",b2)