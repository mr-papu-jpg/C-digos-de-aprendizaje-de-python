import numpy as np

#Crear array de valores mixtos
valores = np.array([-10, -2, 0, 2, 10])

#Aplicar valor absoluto
abs_vals = np.abs(valores)

#Aplicar funciones trigonométricas
senos = np.sin(valores)
cosenos = np.cos(valores)

#Aplicar exponencial y logaritmo
exp_vals = np.exp([1, 2, 3])
log_vals = np.log([1, 2, 3])

#Aplicar raíz cuadrada (solo a positivos)
positivos = np.array([1, 4, 9])
raices = np.sqrt(positivos)

#Redondeo
decimales = np.array([1.3, 2.7, 3.5])
redondeo = np.round(decimales)
piso = np.floor(decimales)
techo = np.ceil(decimales)

#Clipping
original = np.array([2, 5, 9])
limitado = np.clip(original, 3, 7)

print("Abs:", abs_vals)
print("Seno:", senos)
print("Coseno:", cosenos)
print("Exp:", exp_vals)
print("Log:", log_vals)
print("Raíces:", raices)
print("Redondeo:", redondeo)
print("Floor:", piso)
print("Ceil:", techo)
print("Clip:", limitado)