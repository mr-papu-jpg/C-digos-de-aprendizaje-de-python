class Perro:
    def __init__(self, nombre, apellido):
        #metodo constructor
        self.nombre=nombre
        self.apellido=apellido
        