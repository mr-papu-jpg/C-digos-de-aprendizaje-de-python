import pandas as pd

data = {
    'Etapa': ['NumPy - Creación', 'NumPy - Manipulación', 'Pandas - Creación', 'Pandas - Inspección', 'Pandas - Agrupamiento'],
    'Estado': ['Completado', 'Completado', 'Completado', 'En progreso', 'En progreso'],
    'Nivel': [1, 2, 3, 4, 5],
    'Avance': [25, 50, 75, 100, 125]
}

df = pd.DataFrame(data)

print(df.groupby('Estado'))
print()
print(df.groupby('Estado').count())
print()
print(df.groupby('Nivel').mean())

#buscar como usar los usos de las funciones de agg()