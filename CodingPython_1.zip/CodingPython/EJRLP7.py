print(">>INFRESE LA CANTIDAD DE EMPLEADOS: ")
n=int(input())
print("_-_-_-_-_-_")
nomb=[]
suld=[]
for x in range(n):
    nom=input(">>INGRESE NOMBRE: ")
    sul=float(input("INGRESE SUELDO: "))
    nomb.append(nom)
    suld.append(sul)
    print("-------")
aux=0  
for x in range(n-1):
    if suld[x]>suld[x+1]:
        aux=suld[x]
        suld[x]=suld[x+1]
        suld[x+1]=aux
        
print("SUELDOS DE MENOR A MAYOR: \n~~~~~~")        
for x in range(n):
    print(">>",suld[x])        