ln=[]
ln2=[]

suma=[]

for x in range(4):
    n=int(input(">>INGRESE NUMERO 1: "))
    n2=int(input(">>INGRESE NUMERO 2: "))
    ln.append(n)
    ln2.append(n2)
    print("_-_-_-_")
    
for x in range(4):
    sum=ln[x]+ln2[x]
    suma.append(sum)
print("<<<--->>>")    
for x in range(4):
    print(">>", suma[x])