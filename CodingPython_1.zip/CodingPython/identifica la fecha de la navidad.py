fecha=input("ingrese fecha (dd/mm): ")

navidad="25/12"

if fecha==navidad:
    print("Ese dia es navidad")
else:
    print("ese dia no es navidad")