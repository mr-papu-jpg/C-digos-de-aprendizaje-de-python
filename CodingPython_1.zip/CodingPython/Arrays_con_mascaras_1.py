import numpy.ma

am = numpy . ma . array ([1 , 2, 3] , mask =[ True , False , False ])
print(am)

print(am.data)

print(am.__array__())

print(numpy.ma.getdata(am))

print(am.mask)

print(numpy.ma.getmask(am))

print(numpy.ma.getmaskarray(am))

am[1] = numpy.ma.masked
print(am)

am.mask= [0 ,1 ,0]
print(am)

am[1] = -2
print(am)
